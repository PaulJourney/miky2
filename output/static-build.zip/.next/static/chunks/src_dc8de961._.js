(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([typeof document === "object" ? document.currentScript : undefined, {

"[project]/src/lib/supabase.ts [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "getCurrentProfile": (()=>getCurrentProfile),
    "getSession": (()=>getSession),
    "onAuthStateChange": (()=>onAuthStateChange),
    "resetPassword": (()=>resetPassword),
    "signIn": (()=>signIn),
    "signOut": (()=>signOut),
    "signUp": (()=>signUp),
    "supabase": (()=>supabase),
    "updatePassword": (()=>updatePassword),
    "updateProfile": (()=>updateProfile)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$supabase$2d$js$2f$dist$2f$module$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@supabase/supabase-js/dist/module/index.js [app-client] (ecmascript) <locals>");
;
const supabaseUrl = ("TURBOPACK compile-time value", "https://adwjbkjmehkypaetkejw.supabase.co");
const supabaseAnonKey = ("TURBOPACK compile-time value", "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImFkd2pia2ptZWhreXBhZXRrZWp3Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTQ3Mjg0ODcsImV4cCI6MjA3MDMwNDQ4N30.R4XUc6-VNQcXWdioXKJ87x4dQyeguOFFP87KDiixk2g");
const supabase = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$supabase$2d$js$2f$dist$2f$module$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createClient"])(supabaseUrl, supabaseAnonKey);
// Generate unique referral code
function generateReferralCode(email) {
    const timestamp = Date.now().toString(36);
    const emailHash = email.split('@')[0].slice(0, 4).toUpperCase();
    const randomPart = Math.random().toString(36).substring(2, 6).toUpperCase();
    return `${emailHash}${randomPart}${timestamp.slice(-3)}`.substring(0, 10);
}
async function signUp(email, password, fullName, referralCode) {
    try {
        // Create auth user first
        const { data, error } = await supabase.auth.signUp({
            email: email.toLowerCase(),
            password,
            options: {
                data: {
                    full_name: fullName,
                    referred_by: referralCode || null
                }
            }
        });
        if (error) {
            return {
                error: {
                    message: error.message
                }
            };
        }
        if (data.user) {
            // Create or update profile with user info
            const { error: profileError } = await supabase.from('profiles').upsert({
                id: data.user.id,
                email: email.toLowerCase(),
                full_name: fullName,
                referral_code: generateReferralCode(email),
                referred_by: referralCode || null,
                credits: 100,
                water_cleaned_liters: 0,
                subscription_plan: 'free',
                subscription_status: 'active',
                referral_level: 1,
                total_referral_earnings: 0,
                pending_payout: 0,
                language: 'en',
                is_admin: false,
                is_mock: false
            }, {
                onConflict: 'id'
            });
            if (profileError) {
                console.error('Profile creation error:', profileError);
            // Don't fail the signup if profile creation fails
            }
        // Email verification will be handled by Supabase
        // Supabase will send the verification email automatically
        }
        return {
            data,
            error: null
        };
    } catch (error) {
        return {
            error: {
                message: error.message || 'An unexpected error occurred'
            }
        };
    }
}
async function signIn(email, password) {
    try {
        const { data, error } = await supabase.auth.signInWithPassword({
            email: email.toLowerCase(),
            password
        });
        if (error) {
            // Customize error messages
            if (error.message.includes('Invalid login credentials')) {
                return {
                    error: {
                        message: 'Incorrect email or password. Please check your credentials and try again.'
                    }
                };
            }
            if (error.message.includes('Email not confirmed')) {
                return {
                    error: {
                        message: 'Please check your email and click the verification link before signing in.'
                    }
                };
            }
            return {
                error: {
                    message: error.message
                }
            };
        }
        return {
            data,
            error: null
        };
    } catch (error) {
        return {
            error: {
                message: error.message || 'An unexpected error occurred'
            }
        };
    }
}
async function signOut() {
    try {
        const { error } = await supabase.auth.signOut();
        return {
            error
        };
    } catch (error) {
        return {
            error: {
                message: error.message || 'An unexpected error occurred'
            }
        };
    }
}
async function resetPassword(email) {
    try {
        const { error } = await supabase.auth.resetPasswordForEmail(email, {
            redirectTo: `${("TURBOPACK compile-time value", "Miky.ai") || 'https://miky.ai'}/auth/reset-password`
        });
        if (error) {
            return {
                error: {
                    message: error.message
                }
            };
        }
        return {
            error: null
        };
    } catch (error) {
        return {
            error: {
                message: error.message || 'An unexpected error occurred'
            }
        };
    }
}
async function updatePassword(newPassword) {
    try {
        const { error } = await supabase.auth.updateUser({
            password: newPassword
        });
        if (error) {
            return {
                error: {
                    message: error.message
                }
            };
        }
        return {
            error: null
        };
    } catch (error) {
        return {
            error: {
                message: error.message || 'An unexpected error occurred'
            }
        };
    }
}
async function getCurrentProfile() {
    try {
        const { data: { user } } = await supabase.auth.getUser();
        if (!user) {
            return {
                data: null,
                error: null
            };
        }
        const { data: profile, error } = await supabase.from('profiles').select('*').eq('id', user.id).single();
        if (error) {
            // If profile doesn't exist, create it
            if (error.code === 'PGRST116') {
                console.log('Profile not found, creating new profile for user:', user.id);
                const { error: createError } = await supabase.from('profiles').insert({
                    id: user.id,
                    email: user.email?.toLowerCase() || '',
                    full_name: user.user_metadata?.full_name || user.email?.split('@')[0] || 'User',
                    referral_code: generateReferralCode(user.email || ''),
                    credits: 100,
                    water_cleaned_liters: 0,
                    subscription_plan: 'free',
                    subscription_status: 'active',
                    referral_level: 1,
                    total_referral_earnings: 0,
                    pending_payout: 0,
                    language: 'en',
                    is_admin: false,
                    is_mock: false
                });
                if (createError) {
                    console.error('Error creating profile:', createError);
                    // If it's a RLS policy error, try to return a default profile structure
                    if (createError.code === '42501') {
                        console.log('RLS policy blocking profile creation, returning default profile');
                        const defaultProfile = {
                            id: user.id,
                            email: user.email?.toLowerCase() || '',
                            full_name: user.user_metadata?.full_name || user.email?.split('@')[0] || 'User',
                            avatar_url: null,
                            referral_code: generateReferralCode(user.email || ''),
                            referred_by: null,
                            credits: 100,
                            water_cleaned_liters: 0,
                            subscription_plan: 'free',
                            subscription_status: 'active',
                            stripe_customer_id: null,
                            referral_level: 1,
                            total_referral_earnings: 0,
                            pending_payout: 0,
                            language: 'en',
                            is_admin: false,
                            is_mock: true,
                            created_at: new Date().toISOString(),
                            updated_at: new Date().toISOString()
                        };
                        return {
                            data: defaultProfile,
                            error: null
                        };
                    }
                    return {
                        data: null,
                        error: {
                            message: createError.message
                        }
                    };
                }
                // Fetch the newly created profile
                const { data: newProfile, error: fetchError } = await supabase.from('profiles').select('*').eq('id', user.id).single();
                if (fetchError) {
                    return {
                        data: null,
                        error: {
                            message: fetchError.message
                        }
                    };
                }
                return {
                    data: newProfile,
                    error: null
                };
            }
            return {
                data: null,
                error: {
                    message: error.message
                }
            };
        }
        return {
            data: profile,
            error: null
        };
    } catch (error) {
        return {
            data: null,
            error: {
                message: error.message || 'An unexpected error occurred'
            }
        };
    }
}
async function updateProfile(updates) {
    try {
        const { data: { user } } = await supabase.auth.getUser();
        if (!user) {
            return {
                error: {
                    message: 'Not authenticated'
                }
            };
        }
        const { error } = await supabase.from('profiles').update(updates).eq('id', user.id);
        if (error) {
            return {
                error: {
                    message: error.message
                }
            };
        }
        return {
            error: null
        };
    } catch (error) {
        return {
            error: {
                message: error.message || 'An unexpected error occurred'
            }
        };
    }
}
function onAuthStateChange(callback) {
    return supabase.auth.onAuthStateChange(callback);
}
async function getSession() {
    try {
        const { data: { session }, error } = await supabase.auth.getSession();
        return {
            session,
            error
        };
    } catch (error) {
        return {
            session: null,
            error: {
                message: error.message || 'An unexpected error occurred'
            }
        };
    }
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/hooks/useAuth.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "AuthProvider": (()=>AuthProvider),
    "useAuth": (()=>useAuth)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/supabase.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
'use client';
;
;
const AuthContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])({
    user: null,
    profile: null,
    session: null,
    loading: true,
    signOut: async ()=>{},
    refreshProfile: async ()=>{}
});
function AuthProvider({ children }) {
    _s();
    const [user, setUser] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [profile, setProfile] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [session, setSession] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const refreshProfile = async ()=>{
        if (!user) {
            setProfile(null);
            return;
        }
        try {
            const { data: profileData, error } = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getCurrentProfile"])();
            if (error) {
                console.error('Error fetching profile:', error);
                setProfile(null);
            } else {
                setProfile(profileData);
            }
        } catch (error) {
            console.error('Error refreshing profile:', error);
            setProfile(null);
        }
    };
    const handleSignOut = async ()=>{
        try {
            await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].auth.signOut();
            setUser(null);
            setProfile(null);
            setSession(null);
        } catch (error) {
            console.error('Error signing out:', error);
        }
    };
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AuthProvider.useEffect": ()=>{
            // Get initial session
            __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["supabase"].auth.getSession().then({
                "AuthProvider.useEffect": ({ data: { session }, error })=>{
                    if (error) {
                        console.error('Error getting session:', error);
                    }
                    setSession(session);
                    setUser(session?.user ?? null);
                    setLoading(false);
                }
            }["AuthProvider.useEffect"]);
            // Listen for auth changes
            const { data: { subscription } } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$supabase$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["onAuthStateChange"])({
                "AuthProvider.useEffect": async (event, session)=>{
                    console.log('Auth state changed:', event, session?.user?.id);
                    setSession(session);
                    setUser(session?.user ?? null);
                    setLoading(false);
                    // Refresh profile when user signs in
                    if (event === 'SIGNED_IN' && session?.user) {
                        await refreshProfile();
                    }
                    // Clear profile when user signs out
                    if (event === 'SIGNED_OUT') {
                        setProfile(null);
                    }
                }
            }["AuthProvider.useEffect"]);
            return ({
                "AuthProvider.useEffect": ()=>subscription.unsubscribe()
            })["AuthProvider.useEffect"];
        }
    }["AuthProvider.useEffect"], []);
    // Fetch profile when user changes
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AuthProvider.useEffect": ()=>{
            if (user && !profile && !loading) {
                refreshProfile();
            }
        }
    }["AuthProvider.useEffect"], [
        user,
        profile,
        loading
    ]);
    const contextValue = {
        user,
        profile,
        session,
        loading,
        signOut: handleSignOut,
        refreshProfile
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(AuthContext.Provider, {
        value: contextValue,
        children: children
    }, void 0, false, {
        fileName: "[project]/src/hooks/useAuth.tsx",
        lineNumber: 113,
        columnNumber: 5
    }, this);
}
_s(AuthProvider, "+NJFXT68cJiECmjxZQG9c7x1q+U=");
_c = AuthProvider;
function useAuth() {
    _s1();
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(AuthContext);
    if (!context) {
        throw new Error('useAuth must be used within an AuthProvider');
    }
    return context;
}
_s1(useAuth, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU=");
var _c;
__turbopack_context__.k.register(_c, "AuthProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/app/ClientBody.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>ClientBody)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useAuth$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/hooks/useAuth.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
function ClientBody({ children }) {
    _s();
    // Remove any extension-added classes during hydration
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ClientBody.useEffect": ()=>{
            // This runs only on the client after hydration
            document.body.className = "antialiased";
        }
    }["ClientBody.useEffect"], []);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$hooks$2f$useAuth$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AuthProvider"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "antialiased",
            children: children
        }, void 0, false, {
            fileName: "[project]/src/app/ClientBody.tsx",
            lineNumber: 19,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/app/ClientBody.tsx",
        lineNumber: 18,
        columnNumber: 5
    }, this);
}
_s(ClientBody, "OD7bBpZva5O2jO+Puf00hKivP7c=");
_c = ClientBody;
var _c;
__turbopack_context__.k.register(_c, "ClientBody");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
}]);

//# sourceMappingURL=src_dc8de961._.js.map