(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__404369a3._.css",
  "static/chunks/node_modules_@supabase_node-fetch_browser_f3987209.js",
  "static/chunks/node_modules_9514f4d4._.js",
  "static/chunks/src_dc8de961._.js"
],
    source: "dynamic"
});
