(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_2865dbe2._.js",
  "static/chunks/node_modules_ea1968ca._.js"
],
    source: "dynamic"
});
